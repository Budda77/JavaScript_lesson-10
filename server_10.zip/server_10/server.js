let express = require('express');
let server = express();

let bodyParser = require("body-parser");

server.use(express.static(__dirname));
server.use(bodyParser.urlencoded({ 
    extended: true
}));
server.use(bodyParser.json());

server.get("/", function (request, response) {
    console.log('Server started!');
});

server.get('/userGet', function(request,response){
	console.log(request.query);
	response.send('You have successfully used GET method: '+ JSON.stringify(request.query));
});

server.post('/userPost', function(request, response){
	console.log(request.body);
	response.send('You have successfully used POST method: '+ JSON.stringify(request.body));
});


// server for Home Work lesson - 10

server.get('/formGet', function (request, response) {
	console.log(request.query);
    let obj = request.query;
    console.log(obj.userName += ".ValidatedByGET");
    console.log(obj.userSurname += ".ValidatedByGET");
    console.log(obj.userAge += ".ValidatedByGET");
    console.log(obj.userAddress += ".ValidatedByGET");
    response.send('Data :' + JSON.stringify(obj));
    console.log('Data is loaded GET method');
});

server.post('/formPost', function (request, response) {
	console.log(request.body);

    var obj = request.body;
    console.log(obj.userName += ".ValidatedByPOST");
    console.log(obj.userSurname += ".ValidatedByPOST");
    console.log(obj.userAge += ".ValidatedByPOST");
    console.log(obj.userAddress += ".ValidatedByPOST");
    response.send('Data :' + JSON.stringify(obj));
    console.log('Data is loaded POST method');
});

server.listen(3000);




