'user strick'

$(document).ready(function(){
	
	$('#sendGet').bind('click', function(){	
		let userData ={
				userName: $('form#selectors #userName').val(),
				userSurname: $('form#selectors #userSurname').val(),
				userAge: $('form#selectors #userAge').val(),
				userAddress: $('form#selectors #userAddress').val(), 
		};
			
		let element = userData.userAge;
		if(!(isNaN(element)) && (element > 0 && element < 101)){			
		$.ajax({
			type: 'GET',
			contentType: 'application/json',		
			url: 'http://localhost:3000/formGet?userName='+userData.userName+'&userSurname='+userData.userSurname + '&userAge='+userData.userAge +
					'&userAddress='+userData.userAddress,
			success: function(data){
				console.log('success');
				console.log(JSON.stringify(data));
			}
		});		
		}else{
			console.log('Please Enter Correct Data');
			$('div#attributes #userAge').addClass('error');
		}
	});
	
	
	$('#sendPost').bind('click', function(){
		let userData ={
				userName: $('form#selectors #userName').val(),
				userSurname: $('form#selectors #userSurname').val(),
				userAge: $('form#selectors #userAge').val(),
				userAddress: $('form#selectors #userAddress').val(), 
		};
		
		let element = userData.userAge;
		if(!(isNaN(element)) && (element > 0 && element < 101)){
				
		$.ajax({
			type: 'POST',
			data: JSON.stringify(userData),
			contentType: 'application/json',
			url: 'http://localhost:3000/formPost',
			success: function(data){
				console.log('success');
				console.log(JSON.stringify(data));
			}		
		});		
		}else{
			console.log('Please Enter Correct Data');
			$('div#attributes #userAge').addClass('error');
		}
	});
	
});













